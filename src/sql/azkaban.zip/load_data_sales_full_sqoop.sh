#!/bin/bash
source /etc/profile

sqoop job --create sales_customer -- import \
--connect jdbc:mysql://10.30.160.33:3306/sales_source?dontTrackOpenResources=true\&defaultFetchSize=1000\&useCursorFetch=true \
--driver com.mysql.jdbc.Driver \
--username root \
--password 123456 \
--table customer \
--delete-target-dir \
--target-dir /sales_source/customer \
--fields-terminated-by '\001'

sqoop job --create sales_product -- import \
--connect jdbc:mysql://10.30.160.33:3306/sales_source?dontTrackOpenResources=true\&defaultFetchSize=1000\&useCursorFetch=true \
--driver com.mysql.jdbc.Driver \
--username root \
--password 123456 \
--table product \
--delete-target-dir \
--target-dir /sales_source/product \
--fields-terminated-by '\001'

sqoop job --create sales_order -- import \
--connect jdbc:mysql://10.30.160.33:3306/sales_source?dontTrackOpenResources=true\&defaultFetchSize=1000\&useCursorFetch=true \
--driver com.mysql.jdbc.Driver \
--username root \
--password 123456 \
--table sales_order \
--delete-target-dir \
--target-dir /sales_source/sales_order \
--fields-terminated-by '\001'

sqoop job -exec sales_customer
sqoop job -exec sales_product
sqoop job -exec sales_order

hive --database sales_source -e "load data inpath '/sales_source/customer/*' into table sales_source.customer"
hive --database sales_source -e "load data inpath '/sales_source/product/*' into table sales_source.product"
hive --database sales_source -e "load data inpath '/sales_source/sales_order/*' into table sales_source.sales_order"