#!/bin/bash
sqoop job --create sales_customer_incr -- import \
--connect jdbc:mysql://10.30.160.33:3306/sales_source?dontTrackOpenResources=true\&defaultFetchSize=1000\&useCursorFetch=true \
--driver com.mysql.jdbc.Driver \
--username root \
--password 123456 \
--table customer \
--target-dir /sales_source/customer_incr \
--fields-terminated-by '\001' \
--check-column customer_number \
--incremental append \
--last-value 0

sqoop job --create sales_product_incr -- import \
--connect jdbc:mysql://10.30.160.33:3306/sales_source?dontTrackOpenResources=true\&defaultFetchSize=1000\&useCursorFetch=true \
--driver com.mysql.jdbc.Driver \
--username root \
--password 123456 \
--table product \
--target-dir /sales_source/product_incr \
--fields-terminated-by '\001' \
--check-column product_code \
--incremental append \
--last-value 0

sqoop job --create sales_order_incr -- import \
--connect jdbc:mysql://10.30.160.33:3306/sales_source?dontTrackOpenResources=true\&defaultFetchSize=1000\&useCursorFetch=true \
--driver com.mysql.jdbc.Driver \
--username root \
--password 123456 \
--table sales_order \
--target-dir /sales_source/sales_order_incr \
--fields-terminated-by '\001' \
--check-column order_number \
--incremental append \
--last-value 0

sqoop job -exec sales_customer_incr
sqoop job -exec sales_product_incr
sqoop job -exec sales_order_incr

hive --database sales_source -e "load data inpath '/sales_source/customer_incr/*' into table sales_source.customer_incr partition(dt='201907012')"
hive --database sales_source -e "load data inpath '/sales_source/product_incr/*' into table sales_source.product_incr partition(dt='201907012')"
hive --database sales_source -e "load data inpath '/sales_source/sales_order_incr/*' into table sales_source.sales_order_incr partition(dt='201907012')"